using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

/// <summary>
/// Defines the visual representation for a specific color type, 
/// including different icons based on match group size.
/// </summary>
[System.Serializable]
public struct ColorData
{
    public string name;        // Descriptive name for Editor clarity (e.g., "Blue")
    public Sprite defaultIcon; // Standard icon for single items or small groups
    public Sprite iconA;       // Icon for groups passing Threshold A
    public Sprite iconB;       // Icon for groups passing Threshold B
    public Sprite iconC;       // Icon for groups passing Threshold C
}

public class Board : MonoBehaviour
{
    #region Grid Configuration
    [Header("Grid Configuration")]
    [Tooltip("Number of columns (N)")]
    public int width;

    [Tooltip("Number of rows (M)")]
    public int height;

    [Tooltip("Number of distinct item colors (K)")]
    public int colorCount;

    [Tooltip("Time interval for the falling animation.")]
    public float dropTime = 0.5f;
    #endregion

    #region Game Rules
    [Header("Game Rules & Thresholds")]
    [Tooltip("Minimum number of connected blocks required to pop.")]
    public int minMatchCount = 2;

    [Tooltip("Group size required to switch to Icon A.")]
    public int thresholdA = 5;

    [Tooltip("Group size required to switch to Icon B.")]
    public int thresholdB = 7;

    [Tooltip("Group size required to switch to Icon C.")]
    public int thresholdC = 9;
    #endregion

    #region References
    [Header("Prefabs & References")]
    public GameObject itemPrefab;
    public GameObject blastPrefab;
    #endregion

    #region Visuals & UI
    [Header("Visual Assets")]
    public ColorData[] colorAssets;
    public Color[] explosionColors;

    [Header("UI References")]
    public TextMeshProUGUI scoreText;
    #endregion

    #region Private State Variables
    // 2D Array to store the current state of the grid
    private Item[,] allItems;

    // Tracks the player's current score
    private int score = 0;
    #endregion

    /// <summary>
    /// Initializes the board, enforces constraints, and centers the camera.
    /// </summary>
    private void Start()
    {
        // Enforce grid constraints as defined in the technical requirements
        width = Mathf.Clamp(width, 2, 10);
        height = Mathf.Clamp(height, 2, 10);
        colorCount = Mathf.Clamp(colorCount, 1, 6);

        // Initialize the 2D array to store grid items
        allItems = new Item[width, height];

        GenerateBoard();
        CenterCamera();
    }

    /// <summary>
    /// Handles user input (mouse clicks) to interact with the grid items.
    /// </summary>
    private void Update()
    {
        // Detect left mouse button click
        if (Input.GetMouseButtonDown(0))
        {
            // Convert mouse screen position to world coordinates
            Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);

            // Perform a 2D Raycast to detect valid colliders at the click position
            RaycastHit2D hit = Physics2D.Raycast(mousePos, Vector2.zero);

            if (hit.collider != null)
            {
                // Try to get the Item component from the clicked object
                Item clickedItem = hit.collider.GetComponent<Item>();

                if (clickedItem != null)
                {
                    CheckMatches(clickedItem);
                }
            }
        }
    }

    /// <summary>
    /// Generates the initial grid by instantiating items and assigning random colors.
    /// Ensures the starting board is playable by checking for deadlocks immediately.
    /// </summary>
    private void GenerateBoard()
    {
        // 1. Clear any existing children to prevent duplicates or overlaps
        foreach (Transform child in transform)
        {
            Destroy(child.gameObject);
        }

        // 2. Loop through the grid dimensions to create new items
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                // Assign a random color index based on the available color count
                int randomColorIndex = Random.Range(0, colorCount);

                // Instantiate the item prefab at the correct position
                GameObject newObj = Instantiate(itemPrefab, new Vector3(x, y, 0), Quaternion.identity);
                newObj.transform.parent = this.transform;
                newObj.name = $"Item {x},{y}";

                // Configure the Item component
                Item item = newObj.GetComponent<Item>();
                item.x = x;
                item.y = y;
                item.SetColor(randomColorIndex, colorAssets[randomColorIndex].defaultIcon);

                // Store reference in the 2D array
                allItems[x, y] = item;
            }
        }

        // 3. Update visuals based on initial groupings (A/B/C logic)
        UpdateAllIcons();

        // 4. Deadlock Protection:
        // If the randomly generated board has no moves, shuffle it silently (no animation).
        if (IsDeadlocked())
        {
            ShuffleBoard(false);
        }
    }

    /// <summary>
    /// Centers the camera on the grid and adjusts the orthographic size 
    /// to ensure the entire board fits within the screen aspect ratio.
    /// </summary>
    private void CenterCamera()
    {
        // Calculate the center position of the grid
        Vector3 centerPos = new Vector3((width - 1) / 2f, (height - 1) / 2f, -10);
        Camera.main.transform.position = centerPos;

        // Adjust camera size based on aspect ratio
        float aspectRatio = (float)Screen.width / Screen.height;
        float verticalSize = height / 2f + 1; // Add padding
        float horizontalSize = (width / 2f + 1) / aspectRatio;

        // Choose the larger size to ensure the board is never cropped
        Camera.main.orthographicSize = (verticalSize > horizontalSize) ? verticalSize : horizontalSize;
    }

    /// <summary>
    /// Initiates the matching process starting from the clicked item.
    /// If matches exceed the minimum requirement, it destroys items, spawns VFX, updates score, and refills the board.
    /// </summary>
    /// <param name="startItem">The item clicked by the player.</param>
    private void CheckMatches(Item startItem)
    {
        // List to store connected items of the same color
        List<Item> matchedItems = new List<Item>();

        // Start recursive search
        FindConnectedItems(startItem, startItem.colorID, matchedItems);

        // Check if the match count meets the game rule (Min Match Count)
        if (matchedItems.Count >= minMatchCount)
        {
            // Calculate Score: Exponential reward (Count^2 * 10)
            int gain = matchedItems.Count * matchedItems.Count * 10;
            score += gain;

            if (scoreText != null)
                scoreText.text = "Score: " + score;

            // Process each matched item (VFX & Destruction)
            foreach (var item in matchedItems)
            {
                // 1. Spawn Explosion VFX
                GameObject vfx = Instantiate(blastPrefab, item.transform.position, Quaternion.identity);

                // 2. Set VFX Color to match the item's color
                ParticleSystem ps = vfx.GetComponent<ParticleSystem>();
                if (ps != null)
                {
                    var main = ps.main;
                    if (explosionColors != null && item.colorID < explosionColors.Length)
                    {
                        main.startColor = explosionColors[item.colorID];
                    }
                }

                // 3. Ensure VFX renders in front of the board (Z-Axis adjustment)
                Vector3 tempPos = vfx.transform.position;
                tempPos.z = -5f;
                vfx.transform.position = tempPos;

                // 4. Clean up VFX after 1 second
                Destroy(vfx, 1f);

                // 5. Remove item from the grid array and destroy the object
                allItems[item.x, item.y] = null;
                Destroy(item.gameObject);
            }

            // Start the refill process
            StartCoroutine(FillBoard());
        }
    }

    /// <summary>
    /// Recursively finds all connected items of the same color using a Flood Fill algorithm.
    /// Checks adjacent cells (Up, Down, Left, Right) to build a list of matching items.
    /// </summary>
    /// <param name="currentItem">The item currently being checked.</param>
    /// <param name="targetColor">The color ID required for a match.</param>
    /// <param name="result">The list where matching items are stored.</param>
    private void FindConnectedItems(Item currentItem, int targetColor, List<Item> result)
    {
        // Avoid infinite recursion if the item is already processed
        if (result.Contains(currentItem)) return;

        // Stop if the color does not match the target
        if (currentItem.colorID != targetColor) return;

        // Add the valid item to the match list
        result.Add(currentItem);

        // Check neighboring cells (Right, Left, Up, Down) ensuring grid bounds

        // Right
        if (currentItem.x + 1 < width && allItems[currentItem.x + 1, currentItem.y] != null)
            FindConnectedItems(allItems[currentItem.x + 1, currentItem.y], targetColor, result);

        // Left
        if (currentItem.x - 1 >= 0 && allItems[currentItem.x - 1, currentItem.y] != null)
            FindConnectedItems(allItems[currentItem.x - 1, currentItem.y], targetColor, result);

        // Up
        if (currentItem.y + 1 < height && allItems[currentItem.x, currentItem.y + 1] != null)
            FindConnectedItems(allItems[currentItem.x, currentItem.y + 1], targetColor, result);

        // Down
        if (currentItem.y - 1 >= 0 && allItems[currentItem.x, currentItem.y - 1] != null)
            FindConnectedItems(allItems[currentItem.x, currentItem.y - 1], targetColor, result);
    }

    /// <summary>
    /// Coroutine that handles the board's gravity and refill logic.
    /// 1. Drops existing items into empty slots.
    /// 2. Spawns new items at the top.
    /// 3. Updates icon visuals.
    /// 4. Checks for deadlocks and shuffles if necessary.
    /// </summary>
    private IEnumerator FillBoard()
    {
        // PHASE 1: Apply Gravity (Drop existing blocks)
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                // If the current cell is empty, look above for a block to drop
                if (allItems[x, y] == null)
                {
                    for (int k = y + 1; k < height; k++)
                    {
                        if (allItems[x, k] != null)
                        {
                            // Move the found block down to the current empty slot (y)
                            allItems[x, k].y = y;
                            allItems[x, y] = allItems[x, k];
                            allItems[x, k] = null;

                            // Start the falling animation
                            StartCoroutine(MoveItem(allItems[x, y], x, y));

                            // Break inner loop to process the next empty slot
                            break;
                        }
                    }
                }
            }
        }

        // Wait for the drop animations to complete
        yield return new WaitForSeconds(dropTime);

        // PHASE 2: Refill empty slots at the top
        RefillBoard();

        // Brief delay to allow new items to initialize
        yield return new WaitForSeconds(0.2f);

        // Update visuals based on the new board state
        UpdateAllIcons();

        // PHASE 3: Deadlock Check
        // If no moves are possible after refilling, shuffle the board with animation.
        if (IsDeadlocked())
        {
            yield return new WaitForSeconds(0.5f);
            ShuffleBoard(true); // true = Use animation
        }
    }

    /// <summary>
    /// Scans the grid for empty slots (null items) and spawns new items to fill them.
    /// New items are instantiated above the visible board and animated down.
    /// </summary>
    private void RefillBoard()
    {
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                if (allItems[x, y] == null)
                {
                    // Spawn position: Above the visible grid (Height + 2 creates a falling effect)
                    Vector3 startPos = new Vector3(x, height + 2, 0);
                    int randomColorIndex = Random.Range(0, colorCount);

                    // Instantiate the new item
                    GameObject newObj = Instantiate(itemPrefab, startPos, Quaternion.identity);
                    newObj.transform.parent = this.transform;
                    newObj.name = $"Item {x},{y}";

                    // Configure Item component
                    Item item = newObj.GetComponent<Item>();
                    item.x = x;
                    item.y = y;
                    item.SetColor(randomColorIndex, colorAssets[randomColorIndex].defaultIcon);

                    // Register in the grid array
                    allItems[x, y] = item;

                    // Animate the item falling to its target position
                    StartCoroutine(MoveItem(item, x, y));
                }
            }
        }
    }

    /// <summary>
    /// Coroutine to smoothly animate an item from its current position to a target grid coordinate.
    /// </summary>
    /// <param name="item">The item to move.</param>
    /// <param name="targetX">Target column index.</param>
    /// <param name="targetY">Target row index.</param>
    private IEnumerator MoveItem(Item item, int targetX, int targetY)
    {
        Vector3 targetPos = new Vector3(targetX, targetY, 0);
        Vector3 startPos = item.transform.position;
        float elapsedTime = 0;

        // Linear interpolation loop
        while (elapsedTime < dropTime)
        {
            item.transform.position = Vector3.Lerp(startPos, targetPos, elapsedTime / dropTime);
            elapsedTime += Time.deltaTime;
            yield return null;
        }

        // Ensure exact final position to prevent floating point errors
        item.transform.position = targetPos;
    }


    /// <summary>
    /// Iterates through the entire grid to update item visuals based on connected group sizes.
    /// Groups are identified using the Flood Fill algorithm, and sprites are assigned based on A/B/C thresholds.
    /// </summary>
    private void UpdateAllIcons()
    {
        // Track visited cells to ensure each group is processed only once per frame
        bool[,] visited = new bool[width, height];

        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                // Process only valid items that haven't been visited yet
                if (allItems[x, y] != null && !visited[x, y])
                {
                    // 1. Find the connected group for the current item
                    List<Item> currentGroup = new List<Item>();
                    FindConnectedItems(allItems[x, y], allItems[x, y].colorID, currentGroup);

                    // 2. Mark all items in this group as visited
                    foreach (Item item in currentGroup)
                    {
                        visited[item.x, item.y] = true;
                    }

                    // 3. Determine the appropriate sprite based on group size
                    int count = currentGroup.Count;
                    ColorData data = colorAssets[allItems[x, y].colorID];
                    Sprite targetSprite = data.defaultIcon;

                    // Apply Threshold Rules (Check from largest to smallest)
                    if (count >= thresholdC) targetSprite = data.iconC;
                    else if (count >= thresholdB) targetSprite = data.iconB;
                    else if (count >= thresholdA) targetSprite = data.iconA;

                    // 4. Update the sprite for every item in the group
                    foreach (Item item in currentGroup)
                    {
                        item.UpdateSprite(targetSprite);
                    }
                }
            }
        }
    }

    /// <summary>
    /// Scans the grid to determine if any valid moves remain.
    /// A "deadlock" occurs if no two adjacent items share the same color.
    /// </summary>
    /// <returns>True if no matches are found (Game Over/Shuffle needed), otherwise False.</returns>
    private bool IsDeadlocked()
    {
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                if (allItems[x, y] != null)
                {
                    int currentId = allItems[x, y].colorID;

                    // Check Right Neighbor
                    if (x + 1 < width && allItems[x + 1, y] != null && allItems[x + 1, y].colorID == currentId)
                        return false; // Match found, game is playable.

                    // Check Up Neighbor
                    // (Checking Right and Up for every cell covers all necessary adjacencies)
                    if (y + 1 < height && allItems[x, y + 1] != null && allItems[x, y + 1].colorID == currentId)
                        return false; // Match found, game is playable.
                }
            }
        }

        // If the loop finishes without finding a single match, the board is deadlocked.
        return true;
    }

    /// <summary>
    /// Shuffles the board to resolve deadlocks.
    /// Ensures at least one valid match (pair) is created to keep the game playable.
    /// </summary>
    /// <param name="animate">If true, items slide to new positions. If false, they snap instantly (for initial setup).</param>
    public void ShuffleBoard(bool animate)
    {
        List<Item> currentItems = new List<Item>();

        // 1. Collect all valid items currently on the board
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                if (allItems[x, y] != null)
                {
                    currentItems.Add(allItems[x, y]);
                }
            }
        }

        // 2. Guarantee at least one match by reserving a pair of the same color
        List<Item> guaranteedPair = new List<Item>();
        int targetColor = -1;

        // Pick a random color from the existing items
        if (currentItems.Count > 0)
        {
            targetColor = currentItems[Random.Range(0, currentItems.Count)].colorID;
        }

        // Find two items of that color to reserve
        for (int i = currentItems.Count - 1; i >= 0; i--)
        {
            if (currentItems[i].colorID == targetColor && guaranteedPair.Count < 2)
            {
                guaranteedPair.Add(currentItems[i]);
                currentItems.RemoveAt(i);
            }
        }

        // Fallback: If for some reason we couldn't find a pair (extremely rare), pick any two items
        if (guaranteedPair.Count < 2 && currentItems.Count >= 2)
        {
            while (guaranteedPair.Count < 2)
            {
                guaranteedPair.Add(currentItems[0]);
                currentItems.RemoveAt(0);
            }
        }

        // 3. Shuffle the remaining items using the Fisher-Yates algorithm
        for (int i = 0; i < currentItems.Count; i++)
        {
            Item temp = currentItems[i];
            int randomIndex = Random.Range(i, currentItems.Count);
            currentItems[i] = currentItems[randomIndex];
            currentItems[randomIndex] = temp;
        }

        // 4. Redistribute items back into the grid
        int itemIndex = 0;
        int pairIndex = 0;

        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                if (allItems[x, y] != null)
                {
                    Item itemToPlace;

                    // Place the guaranteed pair first (e.g., at the bottom-left) to ensure solvability
                    if (pairIndex < guaranteedPair.Count)
                    {
                        itemToPlace = guaranteedPair[pairIndex];
                        pairIndex++;
                    }
                    else
                    {
                        itemToPlace = currentItems[itemIndex];
                        itemIndex++;
                    }

                    // Update grid reference and item coordinates
                    allItems[x, y] = itemToPlace;
                    itemToPlace.x = x;
                    itemToPlace.y = y;

                    // Apply movement logic
                    if (animate)
                    {
                        // Gameplay: Smooth slide animation
                        StartCoroutine(MoveItem(itemToPlace, x, y));
                    }
                    else
                    {
                        // Initialization: Instant snap
                        itemToPlace.transform.position = new Vector3(x, y, 0);
                    }
                }
            }
        }

        // 5. Update visuals as new groups have formed
        UpdateAllIcons();
    }
} // End of Board Class

