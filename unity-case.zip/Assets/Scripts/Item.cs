using UnityEngine;

/// <summary>
/// Represents a single interactive block on the game board.
/// Manages its own grid coordinates, color identity, and visual rendering.
/// </summary>
public class Item : MonoBehaviour
{
    #region Public State
    [Header("Grid Coordinates")]
    [Tooltip("The X column index on the board.")]
    public int x;

    [Tooltip("The Y row index on the board.")]
    public int y;

    [Header("Properties")]
    [Tooltip("Unique identifier for the color type (e.g., 0=Blue, 1=Red). Used for matching logic.")]
    public int colorID;
    #endregion

    #region Private References
    private SpriteRenderer spriteRenderer;
    #endregion

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    /// <summary>
    /// Initializes the item with a specific color ID and sprite.
    /// Typically called when the item is first spawned.
    /// </summary>
    /// <param name="id">The integer ID representing the item's color group.</param>
    /// <param name="sprite">The visual sprite to display.</param>
    public void SetColor(int id, Sprite sprite)
    {
        colorID = id;
        if (spriteRenderer != null)
        {
            spriteRenderer.sprite = sprite;
        }
    }

    /// <summary>
    /// Updates the item's visual sprite dynamically.
    /// Used when changing icons based on match group sizes (A, B, C states).
    /// </summary>
    /// <param name="newSprite">The new sprite to render.</param>
    public void UpdateSprite(Sprite newSprite)
    {
        if (spriteRenderer != null)
        {
            spriteRenderer.sprite = newSprite;
        }
    }
}